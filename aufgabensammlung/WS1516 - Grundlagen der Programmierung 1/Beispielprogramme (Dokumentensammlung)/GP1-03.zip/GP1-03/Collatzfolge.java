public class Collatzfolge {

	public static void main(String[] args) {
		int n = Integer.parseInt(args[0]);
		System.out.println(n);
		int zaehler = 1;
		int max = n;
		while (n!=1) {
		if (n%2 == 0)
		n = n / 2;
		else
		n = 3 * n + 1;
		System.out.println(n);
		zaehler++;
		if (n > max)
		max = n; }
		System.out.println("Laenge: " + zaehler);
		System.out.println("Maximalwert: " + max);

	}

}
