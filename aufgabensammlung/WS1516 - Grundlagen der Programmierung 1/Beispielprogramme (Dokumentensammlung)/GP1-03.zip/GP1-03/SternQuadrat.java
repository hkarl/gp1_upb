public class SternQuadrat {
	public static void main (String [] args) {
		int reihe, spalte;
		for (reihe = 1; reihe <= 5; reihe++) {
		for (spalte = 1; spalte <= 5; spalte++) {
		if (reihe == 1 || reihe == 5) {
		System.out.print("*"); }
		else { if (spalte == 1 || spalte == 5) {
		System.out.print("*");
		}
		else { System.out.print(" "); }
		}
		}
		System.out.println();
		}
	}

}
