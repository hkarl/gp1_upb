public class TageImMonat {

	public static void main(String[] args) {
		int monat = 2; int jahr = 2000; int anzahlTage = 0;
				switch (monat) {
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					anzahlTage = 31;
				break;
				
				case 4:
				case 6:
				case 9:
				case 11:
					anzahlTage = 30;
				break;
				
				case 2:
					if ( ((jahr % 4 == 0) && !(jahr % 100 == 0)) || (jahr % 400 == 0) )
						anzahlTage = 29;
					else
						anzahlTage = 28;
				break;
				default:
					anzahlTage = 0; 
				break;
	}
	System.out.println("Anzahl Tage = " + anzahlTage);
	}

}
