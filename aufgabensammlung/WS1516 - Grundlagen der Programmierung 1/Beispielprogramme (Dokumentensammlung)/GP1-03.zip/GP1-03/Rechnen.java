public class Rechnen {

	public static void main(String[] args) {
		float eps = 1.0E-8F; // 10^-8
		int factor = 100000000; // 10^8
		float x;
		
		x = 1.0F + factor * eps;
		System.out.println("Ergebnis 1: " + x);
		
		x = 1.0F;
		for (int i = 0; i < factor; i++) {
			x = x + eps;
		};
		System.out.println("Ergebnis 2: " + x);
		
		x = 0.0F;
		for (int i = 0; i < factor; i++) {
		x = x + eps;
		};
		
		x = x + 1.0F;
		System.out.println("Ergebnis 3: " + x);

	}

}
