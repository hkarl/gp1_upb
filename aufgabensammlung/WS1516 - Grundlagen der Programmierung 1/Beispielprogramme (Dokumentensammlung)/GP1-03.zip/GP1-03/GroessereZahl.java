public class GroessereZahl {

	public static void main(String[] args) {
		int zahl1 = Integer.parseInt(args[0]);
		int zahl2 = Integer.parseInt(args[1]);
		/* so ist es noch nicht ganz richtig, warum nicht? */
		if (zahl1 > zahl2)
		{ System.out.println("Die groessere Zahl ist " + zahl1);
		}
		else
		{ System.out.println("Die groessere Zahl ist " + zahl2);
		}
	}

}
