public class Meisterschaft {

	public static void main(String[] args) {
		int j;
		boolean bayernWirdMeister = true;
		boolean werderWirdMeister = false;
		for (j = 1; j < 10; j++) {
		bayernWirdMeister = ! bayernWirdMeister;
		};
		if (j == 10) {
		werderWirdMeister = true;
		};
		System.out.println("Bayern: " + bayernWirdMeister);
		System.out.println("Werder: " + werderWirdMeister);

	}

}
