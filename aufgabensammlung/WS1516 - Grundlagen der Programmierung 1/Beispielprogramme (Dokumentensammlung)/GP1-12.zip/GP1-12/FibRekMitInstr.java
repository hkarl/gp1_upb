
public class FibRekMitInstr {
	static int anzahlAufrufe = 0; // Klassenvariable
	static long fib(int n) {
	anzahlAufrufe++;
	System.out.println("Aufruf Nr."+anzahlAufrufe+":fib("+n+")");
	if (n == 1 || n == 2)
	return 1;
	else
	return (fib(n-1)+fib(n-2));
	}
	public static void main (String [] args) {
	int n = Integer.parseInt(args[0]);
	System.out.print ("Ergebnis: " + fib(n));
	System.out.println (" Anzahl Aufrufe: " +
	anzahlAufrufe);
	}

}
