

public class Hanoi {
    public static void main( String [] args){
	hanoi(4, 'A', 'B', 'C');
    }

    static void hanoi (int hoehe, char quelle, char ablage, char ziel) {
	if (hoehe == 1)
      	       	System.out.println ("lege Scheibe " + hoehe + " von "+ quelle+ " nach " + ziel);
	else
	     {
		hanoi (hoehe - 1, quelle, ziel, ablage);
	    	System.out.println ("lege Scheibe " + hoehe + " von " + quelle+" nach "+ziel);
	      	hanoi (hoehe - 1, ablage, quelle, ziel);
	     }
	}
}
