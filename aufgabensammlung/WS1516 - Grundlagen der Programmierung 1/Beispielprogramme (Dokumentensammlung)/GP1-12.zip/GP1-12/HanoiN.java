

public class HanoiN {
        static int k ; 

	public static void main( String [] args){
	    int n = Integer.parseInt(args[0]) ; 
            hanoi(n, 'A', 'B', 'C');
	}

	static void hanoi (int hoehe, char quelle, char ablage, char ziel) 
        {
	    if (hoehe > 0) 
	       	{
			hanoi (hoehe - 1, quelle, ziel, ablage);
			System.out.println ("lege Scheibe " + hoehe + " von " + quelle+" nach "+ziel);
			hanoi (hoehe - 1, ablage, quelle, ziel);
		}
	}
}
