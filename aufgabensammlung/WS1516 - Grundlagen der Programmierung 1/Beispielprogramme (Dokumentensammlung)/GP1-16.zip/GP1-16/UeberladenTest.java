class Ueberladen {
	void m (String s) {
		System.out.println("Ich bin die String Methode.");
	}
	void m (boolean b) {
		System.out.println("Ich bin die bool Methode.");
	}
	void m (Object o) {
		System.out.println("Ich bin die Object Methode.");
	}
	
}

public class UeberladenTest {
	public static void main (String [] args) {
		String s = "Hallo";
		boolean b = true;
		Object o = new String("bla");
		Integer i = new Integer(3);
		Ueberladen u = new Ueberladen();
		u.m(s);
		u.m(true);
		u.m(i);
		u.m(o);
	}
}