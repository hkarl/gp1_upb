public class SuperTest3 {

	public static void main(String[] args) {
		A a = new A(3);
		B b = new B(4);

	}
}
	class A { 
		A (int x) { System.out.println("Konstruktor	von A"+x); }
	}
	class B extends A {
		B (int x){ super(x); System.out.println("Konstruktor von B"+x); }
		}
	

