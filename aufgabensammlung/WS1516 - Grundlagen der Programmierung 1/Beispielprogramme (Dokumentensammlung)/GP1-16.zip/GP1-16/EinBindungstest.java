public class EinBindungstest {

	public static void main(String[] args) {
		A a = new A();
		System.out.println(a.x);
		B b = new B();
		System.out.println(b.x);
		a = b;
		System.out.println(a.x);

	}

}
class A{
	int x;
	A(){
		x=5;
	}
}
class B extends A{
	int x;
	B(){
		x=7;
	}
}