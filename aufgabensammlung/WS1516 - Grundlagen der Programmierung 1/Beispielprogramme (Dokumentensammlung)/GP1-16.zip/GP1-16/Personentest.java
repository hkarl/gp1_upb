public class Personentest {

	public static void main(String[] args) {
		Person hugo = new Person("Hugo",1234,"Paderborn");
		Student thomas = new Student("Thomas",5678,"Paderborn",3434);
		Bundeskanzler angela = new Bundeskanzler("Angela",1245,"Berlin");
		// wie heisst hugo?
		System.out.println(hugo.name);
		// hat thomas tats�chlich auch einen Namen?
		System.out.println(thomas.name);
		// Wie ist seine Telefonnummer?
		thomas.druckeTelNum();
		// und die der Bundeskanzlerin?
		angela.druckeTelNum();

	}

}
class Person {
	String name;
	int telefonnummer;
	String addresse;
	Person() { }
	Person(String n, int tel, String adr) {
		name = n;
		telefonnummer = tel;
		addresse = adr;
	}
	public void druckeTelNum () {
		System.out.println("Die Telefonnummer von " + name + " ist " + telefonnummer + ".");}
}

class Student extends Person {
	int matrikelnummer;
	Student(String n, int tel, String adr,int matnr) {
		name = n; telefonnummer = tel;
		addresse = adr; matrikelnummer = matnr;
	}
}
class Bundeskanzler extends Person {
	Bundeskanzler(String n,int tel,String adr) {
		name = n;
		telefonnummer = tel;
		addresse = adr;
	}
	public void druckeTelNum () {
		System.out.println("Die Telefonnummer des Bundeskanzlers ist geheim.");
	}
}