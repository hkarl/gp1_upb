
public class SuperTest2 {

	public static void main(String[] args) {
			A a = new A(4);
			B b = new B(5);

	}


class A { 
	A(int x) { System.out.println("Konstruktor von A "+x); }
}
class B extends A {
	B(int x) {
		System.out.println("Konstruktor von B "+x);
	}
}
}
