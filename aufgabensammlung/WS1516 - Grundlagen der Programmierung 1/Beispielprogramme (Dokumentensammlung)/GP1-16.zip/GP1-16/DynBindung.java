class A
{  void m () { System.out.println("m aus Klasse A"); }
   void p () { m(); }
}

class B extends A
{  void m () { System.out.println("m aus Klasse B"); }
}

class C extends B
{  void m () { System.out.println("m aus Klasse C"); }
   void p () { System.out.println("p aus Klasse C"); }
}

public class DynBindung { 
    public static void main (String [] args) {
		A a1 = new A(); a1.p(); 
		A a2 = new B(); a2.m(); 
		B b1 = new B(); b1.p(); 
		A a3 = new B(); a3.p(); 
		A a4 = new C(); a4.p(); 
		B b2 = new C(); b2.p(); 
	}
}
