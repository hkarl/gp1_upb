class Gespenst {
	
	Gespenst() {
		System.out.print("Ich spuke im ");
		}
	Gespenst(String gebaeude) {
		this();
		System.out.print(gebaeude + " von "); 
	}
	void druckeOrt(String ort) {
		System.out.println(ort);
	}
	void druckeAnzahl(int i) {
		System.out.println("und zwar kein mal am Tag.");
	}
}
		
	
	
class UniGespenst extends Gespenst {
	
	UniGespenst(String gebaeude, String ort,int i) {
	    super(gebaeude);
		druckeOrt(ort);
		druckeAnzahl(i);
	}
	
	void druckeOrt(Object o) {
		System.out.println("Schloss Hohenfels");
	}
	void druckeAnzahl(int i) {
		System.out.println("und zwar " + i + " mal am Tag.");
	}
}

public class Gespenstertest {
	
	public static void main (String [] args) {
		Gespenst ug = new UniGespenst("Audimax","Paderborn",3);
	}
}