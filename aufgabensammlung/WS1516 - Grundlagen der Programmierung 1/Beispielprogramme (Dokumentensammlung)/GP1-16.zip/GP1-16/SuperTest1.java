
public class SuperTest1 {

	public static void main(String[] args) {
		System.out.println("new A()");
		A a = new A();
		System.out.println("new B()");
		B b = new B();

	}

}
class A { 
	A () { System.out.println("Konstruktor von A "); }
}
class B extends A {
	B () { System.out.println("Konstruktor von B "); }
}