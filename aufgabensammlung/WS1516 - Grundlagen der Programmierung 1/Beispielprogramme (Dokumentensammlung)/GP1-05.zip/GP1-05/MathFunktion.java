
public class MathFunktion {
	static int max (int zahl1, int zahl2) {
		if (zahl1 > zahl2)
		{return zahl1;}
		else {return zahl2;}
		}
	public static void main (String [] args) {
		int maximum, ergebnis;
		int ersteZahl = 15;
		int zweiteZahl = 42;
		maximum = max(ersteZahl, zweiteZahl);
		System.out.println("Das Maximum ist " + maximum);
		ergebnis = max((ersteZahl * 10) + 3, zweiteZahl - 4);
		System.out.println("Das Ergebnis ist " + ergebnis);
		}
}
