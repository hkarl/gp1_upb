public class CallByValueIllustration {
	static int minusEins (int zahl) {
		zahl--;
		return zahl;
		}
	public static void main (String [] args) {
		int eineZahl = 20;
		int ergebnis;
		ergebnis = minusEins(eineZahl);
		System.out.println("Das Ergebnis ist " + ergebnis);
		System.out.println("Der Wert von eineZahl ist " + eineZahl);
		}

}
