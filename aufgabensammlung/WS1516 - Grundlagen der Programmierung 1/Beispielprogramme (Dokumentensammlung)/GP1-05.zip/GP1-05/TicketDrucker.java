public class TicketDrucker {
	static void eineZeile (int breite, char c)
	{
		System.out.print ('=');
		int i = 2;
		while (i < breite)
		{
			System.out.print (c); i = i+1;
		}
		System.out.println ('=');
		}
	static void einTicket (int breite, int h�he, char c)
	{
		eineZeile (breite, '=');
		int i = 2;
		while (i < h�he)
		{
			eineZeile (breite, c); i = i+1;
		}
		eineZeile (breite, '=');}
	
	public static void main (String []args){
		einTicket (10, 15, '?');
	}

}
