public class CallByValueIllustration2 {
	static int minusEins (int zahl) {
		zahl--;
		return zahl;
		}
	public static void main (String [] args) {
		int zahl = 20;
		int ergebnis;
		ergebnis = minusEins(zahl);
		System.out.println("Das Ergebnis ist " + ergebnis);
		System.out.println("Der Wert von zahl ist " + zahl);
		}

}
