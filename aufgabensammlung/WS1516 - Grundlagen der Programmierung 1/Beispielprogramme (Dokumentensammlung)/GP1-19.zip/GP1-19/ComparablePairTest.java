public class ComparablePairTest {


}
class ComparablePair<T extends Comparable<T>> {
	private T first;
	private T second;
	ComparablePair(T f, T s) {
		first = f;
		second = s;
	}
	public T getFirst() {
		return first;
	}
	public T getSecond(){
		return second;
	}
	public boolean lessThan (ComparablePair<T> cp) {
		return (this.first.compareTo(cp.getFirst()) < 0) || ((this.first.compareTo(cp.getFirst()) == 0) &&(this.second.compareTo(cp.getSecond()) < 0));
		} 
	}