public class Test42GenericBinTree {

	public static void main(String[] args) {
		Tree<Integer> t = new Tree<Integer>( new Integer(5) , null, null ) ;
		for (int i=0; i< args.length ; i++)
			t.insert( Integer.parseInt(args[i]) ) ;
		System.out.println( t.inOrder() ) ;

	}

}
class Tree< T extends Comparable<T> > {
	T wert ;
	Tree<T> left, right ;
	Tree( T i, Tree<T> l, Tree<T> r ) { wert=i; left=l; right=r; }
	
	String inOrder() { return ( left==null ? "" : left.inOrder() )+ " " + wert + " " + ( right==null ? "" : right.inOrder() ) ;
	}
	
	void insert( T i )
	{ if ( i.compareTo(wert) < 0 )
		if (left==null) left = new Tree<T>( i , null , null ) ;
		else left.insert( i ) ;
	else
		if (right==null) right = new Tree<T>( i , null , null ) ;
		else right.insert( i ) ;
	}
}