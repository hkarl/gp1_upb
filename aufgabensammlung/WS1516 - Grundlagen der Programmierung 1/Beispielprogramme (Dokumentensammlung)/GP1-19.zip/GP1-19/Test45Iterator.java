
import java.util.*;

class Node<E> {  
   E data; 
   Node<E> link;
   Node(E d, Node<E> n) {data = d; link = n;}
   
}

class LinList<E> {

   Node<E> start = null;

   public void add(E x) {
      if (start == null) 
         start = new Node<E>(x, null);
      else {
         Node<E> pos = start;
         while (pos.link != null) pos = pos.link;
         pos.link = new Node<E>(x, null);
      }
   }

   public Iterator<E> iterator() { return new ListEnum(); }

   class ListEnum implements Iterator<E>  {
      Node<E> pos = start;
      public boolean hasNext() { return pos != null; }
      public E next() 
         { E x = pos.data; pos = pos.link; return x; }
      public void remove () {
      		throw new UnsupportedOperationException(); }
   }

   public void drucke() {
      Iterator<E> e = iterator();
      System.out.println("------------------------");
      while (e.hasNext()) 
      { System.out.print(e.next()+" "); }
      System.out.println();
   }
}

class Test45Iterator {
   public static <E> boolean finde (LinList<E> l, int x) 
   {
      Iterator<E> e = l.iterator();
      boolean xGefunden = false;

      while (!xGefunden && e.hasNext()) 
      {  xGefunden = (x==((Integer)e.next()).intValue()); }

      return xGefunden;
   }

   public static void main (String [ ] args) 
   {
      LinList<Integer> l = new LinList<Integer>();

      l.add(new Integer(1));
      l.add(new Integer(2));
      l.add(new Integer(0));
      l.drucke();
      if (finde(l, 0)) System.out.println("0 drin");     
   }
}
