class Sauflied 
{

   static String sing (String stuff, int n)
   { // Ein Lied mit n Versen wird durch String-Konkatenation erzeugt.
      String plural, text = ""; // text enth�lt die Referenz des bisher
                                // zusammengef�gten Liedes
      if (n < 1) return ""; 
      if (n == 1) plural = ""; else plural = "s";
      do                       // Den n-ten Vers anh�ngen:
      { text = text +
                   n+" bottle"+plural+" of "+stuff+" on the wall,\n";
        text = text +
                   n+" bottle"+plural+" of "+stuff+"!\n";
        text = text +
                  "You take one down and pass it around:\n";

        n = n - 1;
        if (n == 1) plural = "";      // the last bottle
        if (n == 0)
           text = text + "No bottles of "+stuff+" on the wall!\n";
        else text = text +
                        n+" bottle"+plural+" of "+stuff+" on the wall.\n\n";
      } while (n > 0);
      return text;
   }

   static public void main (String [] args)
   {
      System.out.println(sing(args[0], Integer.parseInt(args[1])));
   }
}

