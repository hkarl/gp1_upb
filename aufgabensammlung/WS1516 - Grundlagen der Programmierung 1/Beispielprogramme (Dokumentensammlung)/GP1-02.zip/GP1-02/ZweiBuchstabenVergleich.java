public class ZweiBuchstabenVergleich {

	public static void main(String[] args) {
		// Variablen deklarieren
		char einBuchstabe;
		char nochEinBuchstabe;
		boolean ersterKleinerAlsZweiter;
		einBuchstabe = 'd';
		nochEinBuchstabe = 'y';
		ersterKleinerAlsZweiter = (einBuchstabe < nochEinBuchstabe);
		System.out.println("Der erste Buchstabe kommt im Alphabet vor dem zweiten ist " + ersterKleinerAlsZweiter);
	}
}
