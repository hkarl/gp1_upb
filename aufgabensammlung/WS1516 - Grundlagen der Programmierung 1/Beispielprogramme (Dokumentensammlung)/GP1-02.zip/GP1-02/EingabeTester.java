public class EingabeTester {

	public static void main(String[] args) {
		
		int anzahl = Integer.parseInt(args[0]) ;
		double w = Double.parseDouble(args[1]) ;
		System.out.println( anzahl + w );

	}

}
