public class ModuloDiv {

	public static void main(String[] args) {
		int a = 4, b = 3;
		int c;
		double d;
		c = a % b; System.out.println(c);
		a = 4; b = -3; c = a % b; System.out.println(c);
		a = -4; b = 3; c = a % b; System.out.println(c);
		a = -4; b = -3;c = a % b; System.out.println(c);
		a = 4; b = 3; c = a / b; System.out.println(c);
		d = a / b; System.out.println(d);
		d = a / 3; System.out.println(d);
		d = (double) a / b; System.out.println(d);
		d = a / (double) b; System.out.println(d);
		d = a / (double) 3; System.out.println(d);
		d = a / 3.0; System.out.println(d);

	}

}
