public class Java2 {
	public static void main (String [] args){
		int zahl1;
		int zahl2;
		int summe;
		zahl1=12;
		zahl2= 3;
		summe= zahl1 + zahl2;
		System.out.println(summe);
	}

}
