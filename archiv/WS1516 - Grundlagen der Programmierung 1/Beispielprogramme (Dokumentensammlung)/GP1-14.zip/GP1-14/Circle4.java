
/** Ein Kreis. 

	Die Klasse beschreibt Kreise, die durch einen Mittelpunkt sowie 
	einen Radius charakterisiert sind. 
	
	@author Heike Wehrheim
	@version 1.2 
*/
public class Circle4 {
	/** Ein Objekt der Klasse Punkt als Mittelpunkt. */
	private Punkt mittelpunkt;
	
	/** Radius des Kreises. */
	private double radius;
	
	/** Konstruktor. 
		@param punkt Das Punktobjekt f�r den Mittelpunkt. 
		@param ir Der Radius. 
	*/ 
	public Circle4 (Punkt punkt, double ir) 
   	{ mittelpunkt = punkt; radius = ir; }
   	
   	/** Ein Getter f�r den X-Wert des Mittelpunktes. 
   		@return X Wert. 
   	*/ 
   	public int getX () { return mittelpunkt.getX(); } 
   	
   	/** Ein Getter f�r den Y-Wert des Mittelpunktes. 
   		@return Y Wert. 
   	*/ 
   	public int getY () { return mittelpunkt.getY(); }
   	
   	/** Ein Getter f�r den Radius. 
   		@return Der Radius. 
   	*/
   	public double getRadius () { return radius; }

	/** Veraenderung des Radius. 
		@param dr Der Wert, um den der Radius veraendert wird.
	*/
  	public void grow (double dr) { radius += dr; }
  	
  	/** Bewegung des Kreises. 
  		@param dx Der X Wert, um den verschoben wird. 
  		@param dy Der Y Wert, um den verschoben wird. 
  	*/ 
   	public void move (int dx, int dy) { mittelpunkt.move(dx,dy); }
   	
   	/** toString Methode fuer Kreise.  
   		@return Eine Zeichenkette, die den Kreis beschreibt. 
   	*/ 
   	public String toString () {
   		return "Ich bin ein Kreis mit Mittelpunkt " + "(" + 
   				mittelpunkt.getX() + " , " + 
   		        mittelpunkt.getY() + ")"+ " und Radius " + radius; 
   	}
}
