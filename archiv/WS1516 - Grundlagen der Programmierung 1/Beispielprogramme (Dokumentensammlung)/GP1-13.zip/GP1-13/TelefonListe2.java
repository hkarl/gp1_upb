
public class TelefonListe2 {

	public static void main(String[] args) {
		// Hier k�nnten Ihre Programmaufrufe stehen

	}
	static void selectSort (Sortable [] arr) {
		// am Ende ist arr sortiert, so dass f�r kein i
		// gilt: arr[i+1].lessThan(arr[i])
		for (int left = 0;left < arr.length-1; left++) {
		// find smallest element from left to last
			int min = left;
			for (int j = left+1; j < arr.length; j++)
				if (arr[j].lessThan (arr[min])) min = j;
		// left und min tauschen
			Sortable tmp = arr[min];
			arr[min] = arr[left];
			arr[left] = tmp;
		}
	}
}
interface Sortable {
	boolean lessThan (Sortable a);
}
class Telefon implements Sortable {
	int telefonnr;
	String name;
	public Telefon(int nr, String n){
		telefonnr=nr;
		name=n;
	}
	public boolean lessThan (Sortable a) {
		return name.compareTo(((Telefon)a ).name )<0;
	}
}
