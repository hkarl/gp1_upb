public class EssbarTest {

	public static void main(String[] args) {
		Essbar essen1 = new Erdbeere(0);
		Essbar essen2 = new Kaese("Harzer");
		System.out.println("Essen1 schmeckt " +
		((essen1.geschmackswert() > 5) ?
		"lecker" : "igitt"));
		System.out.println("Essen2 schmeckt " +
		((essen2.geschmackswert() > 5) ?
		"lecker" : "igitt"));
		}

	}


interface Essbar {
	public int geschmackswert();
}
class Erdbeere implements Essbar {
	static final int geschmack = 10;
	int alter;
	Erdbeere(int alter) {
		this.alter = alter;
	}
	public int geschmackswert() {
		return geschmack - alter;
	}
}
class Kaese implements Essbar {
	String sorte;
	Kaese (String sorte) {
		this.sorte = sorte; }
	public int geschmackswert () {
		if (sorte.equals("Gouda")) {
			return(5); }
		else { if (sorte.equals("Greyerzer")) {
			return(8); }
				else { if (sorte.equals("Harzer")) {
					return(3); }
						else { return(4); }
				}
		}
	}
}
interface Sortierbar {
	public boolean groesserAls(Object o);
}

class Erdbeere2 implements Essbar, Sortierbar {
	static final int geschmack = 10;
	int alter;
	int gewicht;
	Erdbeere2(int alter, int gewicht) {
		this.alter = alter;
		this.gewicht = gewicht;
	}
	public int geschmackswert() {
		return geschmack - alter;
	}
	public boolean groesserAls(Object o) {
		return this.gewicht >=
				((Erdbeere2) o).gewicht; }
}