public class Hundebesitzer {

	public static void main(String[] args) {
		Hund bello = new Hund();
		bello.laufe();
		bello.laufe(10);

	}

}
interface Tierisch{
	void laufe();
}
interface Laufend{
	void laufe( int kmh);
}
class Hund implements Laufend, Tierisch {
	public void laufe() {
		System.out.println("Ich laufe langsam.");
	}
	public void laufe(int kmh) {
		System.out.println("Ich laufe " + kmh + " Stundenkilometer schnell.");
	} 
}