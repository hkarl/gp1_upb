
public class FuncNutzer {

	public static void main(String[] args) {
		Funktion f = new Quadrat();
		System.out.println(f.at(6));
		System.out.println(f.name());
		werteTafel(f, 0.0, 2.0, 0.2);
		werteTafel(new Wurzel(), 0.0, 1.0, 0.1);

	}
	static void werteTafel(Funktion f, double von, double bis, double schritt) {
		System.out.println("Wertetabelle der Funktion "+f.name());
		for (double x = von; x <= bis;
				x += schritt)
			System.out.println(f.name()+"("+x+
					") = "+f.at(x));
		}

}
interface Funktion {
	// sagt, was Funktion-Objekte anbieten
	double at(double x);
	// Funktionswert an der Stelle x
	String name();
	// Name der Funktion
}
class Quadrat implements Funktion {
	public double at(double arg) {
		return arg*arg ; }
	public String name() {
		return "Quadrat" ; }
}
class Wurzel implements Funktion {
	public double at(double arg) {
		return Math.sqrt(arg); }
	public String name() {
		return "Wurzel"; }
}
class Absolut implements Funktion{
	public double at(double arg) {
		return Math.abs(arg);
	}
	public String name() {
		return "Absolut";
	}
}
class Hoch4 implements Funktion{
	Funktion f = new Quadrat() ;
	public double at(double arg) {
		return f.at(arg)*f.at(arg);
	}
	public String name() {
		return "Hoch4";
	}
}
