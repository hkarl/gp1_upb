public class TelefonListe {
	public static void main( String[] args ) {
		Telefon [] telefonbuch = {
		new Telefon( "Peter" , 12345 ) ,
		new Telefon( "Anna" , 23753 ) ,
		new Telefon( "Anton" , 12314 ) ,
		new Telefon( "Monika", 44117 )
		} ;
		sort(telefonbuch) ;
	}
	static void sort( HasKey[] arr ) {
		int left , min , test ;
		for ( left=0; left < arr.length-1; left++) {
			min = left ;
			for(test = left+1;test < arr.length;test++){
				if (arr[test].getKey().compareTo(arr[min].getKey() ) < 0)
					min = test;
			}
			tausche(arr,min,left);
		}
	}
	static void tausche( HasKey[] arr, int l, int m) {
		HasKey hilf = arr[l];
		arr[l] = arr[m];
		arr[m] = hilf;
		}
}
interface HasKey {
	String getKey();
// gib den Schl�sselwert f�r einen Datensatz zur�ck
}
class Telefon implements HasKey {
	String name ;
	int telefonnr ;
	Telefon( String n , int tel ) {
		name=n ; telefonnr=tel ;
	}
	public String getKey() {
		return name ;
	}
	public String toString() {
		return "( "+name+" : "+telefonnr+" )"; }
}