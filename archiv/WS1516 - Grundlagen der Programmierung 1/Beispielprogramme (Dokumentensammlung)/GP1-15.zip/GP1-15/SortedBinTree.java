public class SortedBinTree {
	int value;
	SortedBinTree left;
	SortedBinTree right;
	SortedBinTree (int v) {
		value = v;
		left = null;
		right = null;
	}
	public static void main(String[] args) {
		// Hier k�nnten Ihre Programmaufrufe stehen

	}
	void insert (int v) {
		if (v == value)
			System.out.println("Value already existed.");
		else
			if (v < value) {
				if (left!= null)
					left.insert(v);
				else
					left = new SortedBinTree(v);
			}
			else {
				if (right!= null)
					right.insert(v);
				else
					right = new SortedBinTree(v);
			}
		}

}
