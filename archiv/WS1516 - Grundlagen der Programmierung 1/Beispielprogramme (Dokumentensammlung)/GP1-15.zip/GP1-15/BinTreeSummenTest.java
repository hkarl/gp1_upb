class BinTree	// Bin�re B�ume mit Zahlenwerten an den Baumknoten
{
   private BinTree left, right;
   private int value;
  
   BinTree (BinTree l, int v, BinTree r)	// Konstruktor f�r innere Knoten
   { left = l; value = v; right = r; }

   BinTree (int v)	// Konstruktor f�r Blattknoten
   { left = null; value = v; right = null; }
   
   int summeKnoten () {
   		int summe = 0;
   		summe+= value; 
   		if (left != null) 
   			summe += left.summeKnoten();
   		if (right != null)
   			summe += right.summeKnoten();
   		return summe;  
   	}
   	
   	int anzahlKnoten() {
   		int anzahl = 1;
   		if (left != null) 
   			anzahl += left.anzahlKnoten();
   		if (right != null)
   			anzahl += right.anzahlKnoten();
   		return anzahl; 
   	}
}
   

class BinTreeSummenTest
{

   public static void main (String [] args)
   {
      BinTree b1 = new BinTree(2);
      BinTree b2 = new BinTree(3);
      BinTree b3 = new BinTree(b1, 6, b2);
      BinTree b4 = new BinTree(4);
      BinTree b5 = new BinTree(b4, 8, null);
      BinTree b6 = new BinTree(b5, 3, b3);
      System.out.println(b6.summeKnoten());
      System.out.println(b6.anzahlKnoten());
    }
}