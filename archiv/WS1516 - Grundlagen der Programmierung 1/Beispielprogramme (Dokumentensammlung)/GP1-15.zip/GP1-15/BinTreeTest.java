public class BinTreeTest {

	public static void main(String[] args) {
		BinTree b1 = new BinTree(2);
		BinTree b2 = new BinTree(3);
		BinTree b3 = new BinTree(b1, 6, b2);
		BinTree b4 = new BinTree(4);
		BinTree b5 = new BinTree(b4, 8, null);
		BinTree b6 = new BinTree(b5, 3, b3);
		
		BinTree b7 =
				new BinTree(
						new BinTree(
								new BinTree(4),
								8,
								null),
						3,
						new BinTree(
								new BinTree(2),
								6,
								new BinTree(3))
				);
		
		b6.inFix();
		b6.postFix();
	}

}
class BinTree {
	private BinTree left, right;
	private int value;
	// Konstruktor f�r innere Knoten
	BinTree (BinTree l, int v, BinTree r)
		{ left = l; value = v; right = r; }
	// Konstruktor f�r Blattknoten
	BinTree (int v)
		{ left = null; value = v; right = null; }
	void inFix() { // Ausgabe in Infix-Form,
		// geklammert
		System.out.print("(");
		// Drucke linken Teilbaum
		if (left !=null) left.inFix();
			// Drucke eigenen Wert
			System.out.print(value);
		// Drucke rechten Teilbaum
		if (right !=null) right.inFix();
		System.out.print(")");
		}
	void postFix() {
		// Ausgabe in Postfix-Form
		// ohne Klammern
		// Drucke linken Teilbaum
		if (left !=null) left.postFix();
		// Drucke rechten Teilbaum
		if (right !=null) right.postFix();
		// Drucke eigenen Wert
		System.out.print(value);
		}
	int summeKnoten () {
		int summe = 0;
		summe += value;
		if (left != null)
			summe += left.summeKnoten();
		if (right != null)
			summe += right.summeKnoten();
		return summe;
		}
	int baumTiefe() {
		int l = left==null ? 0 : left.baumTiefe() ;
		int r = right==null ? 0 : right.baumTiefe() ;
		return l>=r ? l+1 : r+1  ;
		}
}