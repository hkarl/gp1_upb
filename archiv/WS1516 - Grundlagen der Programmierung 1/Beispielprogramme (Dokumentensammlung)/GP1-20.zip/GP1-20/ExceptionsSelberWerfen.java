import java.io.IOException;

public class ExceptionsSelberWerfen {

	public static void main(String[] args) {
		try {
			throw new IOException("hier ist ein ganz bl�der Fehler aufgetreten");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
