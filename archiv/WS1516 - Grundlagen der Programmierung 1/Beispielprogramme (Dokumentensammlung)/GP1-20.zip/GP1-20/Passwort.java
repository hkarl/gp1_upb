import java.util.Scanner; 

public class Passwort {
	public static void main(String [] args) {
		String passwort = "xyz0d,"; 
		Scanner sc = new Scanner(System.in); 
		
		boolean richtig = false; 
		int i = 0; 
		String eingabe; 
		
		while(!richtig && i < 5) {
			System.out.print("Bitte geben Sie Ihr Passwort ein: "); 
			eingabe = sc.nextLine(); 
			i++; 
			if (passwort.compareTo(eingabe) != 0) 
				System.out.println("Passwort falsch."); 
			else
				richtig = true; 
		}
		if (!richtig) 
			System.out.println("Keine weitere Eingaben moeglich."); 
		else
			System.out.println("Passwort akzeptiert."); 
	}
}	