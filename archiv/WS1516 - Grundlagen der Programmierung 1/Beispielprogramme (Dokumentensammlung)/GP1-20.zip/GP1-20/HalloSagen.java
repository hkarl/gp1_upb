
import java.util.Scanner;
public class HalloSagen {

	public static void main(String[] args) {
		String name;
		Scanner tastatur=new Scanner(System.in);
		System.out.print("Wie heisst du? ");
		name = tastatur.nextLine();
		System.out.println("Hallo " + name);

	}

}
