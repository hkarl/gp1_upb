
import java.util.Scanner;
public class DatenEinlesen {

	public static void main(String[] args) {
		String name;
		int alter = -1; // -1: Alter undefiniert
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Bitte Nachname Vorname Alter: ");
		name = eingabe.nextLine();
		Scanner s = new Scanner(name);
		String nachname = s.next();
		String vorname = s.next();
		if (s.hasNextInt())
			alter = s.nextInt();
		System.out.println("Vorname:" + vorname + "\nNachname: "+nachname + "\nAlter: " + alter);

	}

}
