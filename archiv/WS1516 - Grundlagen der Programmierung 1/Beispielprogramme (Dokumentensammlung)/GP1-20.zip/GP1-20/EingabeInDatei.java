
import java.util.Scanner;
import java.io.*;
public class EingabeInDatei {

	public static void main(String[] args) throws IOException { 
		Scanner tastatur = new Scanner(System.in);
		String zeile;
		PrintStream ausgabe = new PrintStream (new File("Daten.txt"));
		do {
			System.out.print("Ihre naechste Eingabe bitte oder E:");
			zeile = tastatur.nextLine();
			ausgabe.println(zeile); }
		while (! zeile.equals("E"));
		ausgabe.close();
	}

}
