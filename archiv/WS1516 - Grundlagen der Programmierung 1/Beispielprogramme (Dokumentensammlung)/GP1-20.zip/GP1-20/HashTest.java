
import java.io.*;
import java.util.*;
public class HashTest {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		HashMap<String,String> nameAnschrift =
		new HashMap<String,String>(20);
		// Einleseschleife, Beenden mit �ende�
		boolean eingabeZuEnde = false;
		while (!eingabeZuEnde) {
			System.out.print("Name: ");
			String name = eingabe.nextLine();
			if (name.compareTo("ende") != 0) {
			// Eingabe = �ende� ?
			// NEIN
				System.out.print("Anschrift: ");
				String anschrift = eingabe.nextLine();
				nameAnschrift.put(name, anschrift);
			}
			else
				eingabeZuEnde=true;
		// Abfrageschleife, Beenden mit �ende�
			boolean abfragenZuEnde = false;
			while (!abfragenZuEnde) {
				System.out.print("Name? ");
				name = eingabe.nextLine();
				if (name.compareTo("ende") != 0) {
					if (nameAnschrift.containsKey(name))
						// name existiert
						System.out.println("Anschrift: "+
								(String) nameAnschrift.get(name));
					else
						System.out.println("Kein Eintrag fuer "+name);
				}
				else
					abfragenZuEnde=true;
			}

	}

}
}
