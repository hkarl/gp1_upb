public class ExceptionWeiterreichen {
	static void innersteMethode () {
		int a = 3; 
		int b = 0;
		a = a / b; // Teilen durch 0 nicht erlaubt
		System.out.println("Nach der Division"); }
	static void aeussereMethode () {
		innersteMethode();
		System.out.println("Nach dem Aufruf von innersteMethode"); }
	
	public static void main(String[] args) {
		try {
			aeussereMethode();
			}
			catch (ArithmeticException e) {
			System.out.println("Hier habe ich was gefangen, und zwar");
			System.out.println(e); }

	}

}
