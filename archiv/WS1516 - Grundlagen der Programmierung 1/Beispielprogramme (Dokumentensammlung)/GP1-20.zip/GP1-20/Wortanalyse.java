
import java.util.Scanner;
public class Wortanalyse {

	public static void main(String[] args) {
		String zeile;
		Scanner tastatur = new Scanner(System.in);
		zeile = tastatur.nextLine();
		Scanner s = new Scanner(zeile);
		int i = 1;
		while (s.hasNext()) {
			System.out.println("Teil " + i + ": " + s.next());
			i++;
		}
	}

}
