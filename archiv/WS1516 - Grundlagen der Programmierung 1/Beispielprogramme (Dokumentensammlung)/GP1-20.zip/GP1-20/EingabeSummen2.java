import java.util.Scanner; 

public class EingabeSummen2 { 
   public static void main(String[] args) {
      Scanner in = new Scanner(System.in);
      int total = 0;
      int i = 1 ; 
      System.out.print ("Abbruch mit E " + i + ">");
      while( in.hasNextInt() )   {  // Abbruchbedingung
             total += in.nextInt();
             System.out.print ("Abbruch mit E " + i + ">");
      }
      System.out.println ("\n Danke!");
      System.out.println ("Die Summe der Zahlen ist " + total);
   }
}
