public class ThrowTest {

	public static void main(String[] args) {
		double a = 1.0e290, b = 1.0e-14, c = 0.0;
		try { 
			if (-0.000000000000001 < b && b < 0.000000000000001)
		{ throw new ArithmeticException();}
		c = a/b;
		}
		catch(ArithmeticException e) {
		System.out.println("Division durch "+b+ " geht nicht.");
		}
	}

}
