import java.io.*;
import java.util.*; 

public class DateiAusgeben
{ 
   static void dateiAusgeben(Scanner datei, String dateiName)
   {	
      System.out.println("================="+dateiName+"=================");
      try 
      { 
         while (true) {
         	System.out.println(datei.nextLine()); 
         }
      }
      catch (NoSuchElementException e)
      { System.out.println("=================================================="); }
   }

   public static void main(String[] args)
   {
      Scanner tastatur = new Scanner(System.in);
      System.out.print("Bitte Dateinamen eingeben: "); 
      String dateiname = tastatur.nextLine();
      File datei = new File(dateiname); 
      Scanner eingabe = null; 
      boolean dateiDa = true; 
      
      try {
      	eingabe = new Scanner(datei); 
      }
      catch (FileNotFoundException e) {
      	dateiDa = false; 
      }
      
      if (dateiDa) 
      	dateiAusgeben(eingabe, dateiname);
      else                
      	System.out.println(dateiname+" nicht gefunden");
   }
}
