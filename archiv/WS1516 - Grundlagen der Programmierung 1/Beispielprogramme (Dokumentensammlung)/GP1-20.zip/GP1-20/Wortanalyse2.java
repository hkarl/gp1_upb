
import java.util.Scanner;
import java.io.*;
public class Wortanalyse2 {

	public static void main(String[] args) {
		String zeile;
		Scanner datei;
		try {
			datei = new Scanner(new File("Wortanalyse2.java"));
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		while (datei.hasNextLine()) {
			zeile = datei.nextLine();
			Scanner s = new Scanner(zeile);
			int i = 1;
			while (s.hasNext()) {
				System.out.println("Teil " + i + ": " + s.next());
				i++; }
			System.out.println("=========");
		}

	}

}
