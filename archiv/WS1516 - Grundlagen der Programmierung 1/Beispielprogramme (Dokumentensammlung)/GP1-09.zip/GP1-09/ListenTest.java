


public class ListenTest {

	public static void main(String[] args) {
		Node list = new Node (5, null);
		
		for (int i = 10; i > 0; i--)
			list = new Node (i, list);
		
		Node l = list;
		while (l != null) {
				System.out.print(l.data+" ");
				l = l.link;
		}
		
		l= list;
		int zahl= 6;
		boolean gefunden = false;
		while ((l != null) & !gefunden)
		{
			if (l.data == zahl)
				gefunden = true;
			else l = l.link;
		}
		if(gefunden){
			System.out.println("Die Liste enth�lt das Element "+ zahl);
		}
		else{
			System.out.println("Die Liste enth�lt das Element "+ zahl+ " nicht");
		}
		
		Sequence seq = new Sequence(); 
		seq.zeige();
		seq.insert(1); 
		seq.zeige();
		seq.succ();
		seq.zeige();
		seq.insert(2); 
		seq.zeige();
		seq.reset(); 
		seq.zeige();
		seq.succ(); 
		seq.zeige();
		seq.remove(); 
		seq.zeige();
	}

}
class Node {
	int data;
	Node link;
	Node (int d, Node n) {
		data = d; link = n;
	}
}
class Sequence {
	private Node start,prev,now; // die 3 lokalen Variablen
	public Sequence() {
		start = null; prev = null;
		now = null;
		} // Konstruktor
	public void insert (int x){
		Node newElem = new Node (x, now);
		if (prev == null) start = newElem;
		else prev.link = newElem;
		now = newElem;// Element x an aktueller Position einf�gen
		}
	public void remove () {
		now = now.link;
		if (prev == null) start = now;
		else prev.link = now;
		} // Element l�schen
	public int current () {return now.data;} // Wert des aktuellen Elementes
	public void succ() {
		Node tmp = now;
		now = now.link;
		prev = tmp;
		} // Position weitersetzen
	public void reset () {prev = null; now = start;} // Position an den Anfang zur�cksetzen
	public boolean isEol () {return now == null;} // ist die Position au�erhalb der Liste?
	public boolean isEmpty () {return start == null;} // ist die Liste leer?
	public void zeige() {
		Node p = start;
		System.out.print( "<" ) ;
		while (p != null) {
			if (p==now) System.out.print(" *");
			System.out.print(" " + p.data) ;
			p = p.link;
		}
		if (now==null) System.out.print(" *");
		System.out.println(" >");
		}
	
	}
