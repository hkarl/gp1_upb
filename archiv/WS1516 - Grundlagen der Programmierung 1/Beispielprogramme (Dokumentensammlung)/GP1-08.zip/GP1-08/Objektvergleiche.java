class Zahl {
	int zahl;
 
	void incr() {
		zahl++;
	}
	
	void decr() {
		zahl--;
	}
	
	public boolean istGleich(Zahl zahlObjekt) {
		return this.zahl == zahlObjekt.zahl;
	}
	
	Zahl(int wert) {
		zahl = wert;
	}
}
															 

public class Objektvergleiche {
	
	public static void main (String [] args) {
		Zahl z1, z2, z3; 
		
		z1 = new Zahl(9);
		z2 = new Zahl(11);
		z3 = z1;
		z2.decr();
		z3.incr();
		
		System.out.println(z1 == z2);
		System.out.println(z1.istGleich(z2));
		System.out.println(z2.istGleich(z1));
		System.out.println(z1 == z3);
		System.out.println(z1.istGleich(z3));
	}
} 