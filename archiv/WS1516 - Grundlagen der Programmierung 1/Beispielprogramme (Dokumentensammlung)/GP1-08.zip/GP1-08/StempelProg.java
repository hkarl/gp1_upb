public class StempelProg {
	
	public static void main (String [] args) {
		Stempel stempel1 = new Stempel(5,4);
		Stempel stempel2 = new Stempel(10,3);
		
		stempel1.einTicket('?');
		stempel2.einTicket('4');
	}
}