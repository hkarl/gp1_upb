class Zahl {
	public int zahl;
	
	void druckeZahl() {
		System.out.println("Der Wert ist " + zahl);
	}
	
	Zahl() {
		zahl = 10;
	}
}

public class CallByValueIllustration3 {
	
	static void minusEins (Zahl zahlObjekt) {
		zahlObjekt.zahl--;
	}
	
	public static void main (String [] args) {
		Zahl eineZahl = new Zahl();
		
		minusEins(eineZahl);
		eineZahl.druckeZahl();
	}
}
		