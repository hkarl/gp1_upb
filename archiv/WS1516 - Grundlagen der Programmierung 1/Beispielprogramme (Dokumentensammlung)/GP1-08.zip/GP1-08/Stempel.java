class Stempel {
	private int hoehe, breite;
	private static final char rand = '=';
	
	Stempel(int h, int b) {
		hoehe = h; breite = b;
	}

	private void eineZeile (char c) {
      System.out.print (rand);
      int i = 2;
      while (i < breite)
      { System.out.print (c); i = i+1; }
      System.out.println (rand);
   	}

   	public void einTicket (char c) {
      eineZeile ('=');
      int i = 2;
      while (i < hoehe)
    	  { eineZeile (c); i = i+1; }
      eineZeile ('=');
  	 }
}