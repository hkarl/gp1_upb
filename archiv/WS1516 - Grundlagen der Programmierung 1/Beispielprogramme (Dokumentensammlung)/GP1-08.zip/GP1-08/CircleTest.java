public class CircleTest {
	
	public static void main (String [] args) {
		Circle c1 = new Circle(0,0,1.0);
		
		c1.printC();
		c1.move(3,4);
		c1.printC();
		c1.grow(4.0);
		c1.printC();
	}
}