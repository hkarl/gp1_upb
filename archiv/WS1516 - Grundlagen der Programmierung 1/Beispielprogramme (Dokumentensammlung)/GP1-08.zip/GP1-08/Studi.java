public class Studi {	
	private int matNummer; 
	private int alter; 
	Studi(int mNum, int wieAlt) { 
		matNummer = mNum; alter = wieAlt;
	}
	void �ndereMatNr(int mNum) { 
		matNummer = mNum; 
	}
	void erh�heAlter() { alter++; }
	
	void drucke() {
		System.out.println("Matnr.: " + matNummer + " , Alter: " + alter);
	}
}
