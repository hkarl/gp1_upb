public class Circle {
	int x, y;
	double radius; 
	    
  	int getX () { return x; }
  	int getY () { return y; }
  	double getRadius () { return radius; }
  	
  	void grow (double dr) { radius += dr; }
  	void move (int dx, int dy) { 
			x += dx; y += dy; }
	void printC() {
		System.out.println("Ich bin ein Kreis an Position (" + x + "," + y + 
		                    ") mit Radius " + getRadius());
    }
			
	Circle (int ix, int iy, double ir)   
		{ x = ix; y = iy; radius = ir; }
}
