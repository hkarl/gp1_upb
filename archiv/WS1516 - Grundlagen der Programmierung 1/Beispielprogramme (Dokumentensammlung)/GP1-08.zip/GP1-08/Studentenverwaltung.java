public class Studentenverwaltung {
		private Studi [] studenten; 
		private int anzahl; 
		
		Studentenverwaltung(int max) {
			studenten = new Studi[max];
			for (int i = 0; i < max; i++)
				studenten[i] = null;
			anzahl = 0;
		} 
		
		public void druckeStudis() {
			for (int i = 0; i < anzahl; i++) 
				studenten[i].drucke(); 
		}
		
		public void neuerStudi(Studi s) {
			studenten[anzahl] = s; 
			anzahl++;
		}	
		
		Studi gibStudi(int mNr) {
			return studenten[mNr - 1]; 
		}
	
		public static void main (String [] args) {
			Studentenverwaltung studisgp1 = new Studentenverwaltung(350); 
			studisgp1.druckeStudis(); 
			Studi s1 = new Studi(1,20);
			Studi s2 = new Studi(2,19); 
			studisgp1.neuerStudi(s1);
			studisgp1.neuerStudi(s2); 
			studisgp1.druckeStudis(); 
			studisgp1.gibStudi(2).drucke(); 
		}
}
