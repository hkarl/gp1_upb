public class StudentProg {
	
	public static void main(String[] args) {
		StudentEinfach studi1 = new StudentEinfach(1,21);
		StudentEinfach studi2 = new StudentEinfach(2,24);
		
		studi1.erhoeheAlter();
		studi2.aendereStudiengang('M');
		studi1.druckeStudi();
		studi2.druckeStudi();
	}
}