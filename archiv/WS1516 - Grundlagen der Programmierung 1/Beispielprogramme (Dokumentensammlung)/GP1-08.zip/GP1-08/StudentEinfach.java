class StudentEinfach {
	private int matNummer, alter; 
	private char studiengang;
	
	StudentEinfach(int mNum, int wieAlt) { 
		matNummer = mNum; alter = wieAlt; studiengang = 'B';
	}
	void aendereMatNr(int mNum) { 
		matNummer = mNum; 
	}
	void erhoeheAlter() { 
		alter++; 
	}
	void aendereStudiengang(char studiengangNeu) {
		studiengang = studiengangNeu;
	}
	
	void druckeStudi() {
		System.out.println("Matrikelnummer: " + matNummer);
		System.out.println("Alter: " + alter);
		System.out.println("Studiengang: " + studiengang);
	}
}
