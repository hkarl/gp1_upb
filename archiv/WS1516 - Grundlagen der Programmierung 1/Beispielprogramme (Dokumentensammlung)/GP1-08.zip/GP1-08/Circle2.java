package kreise;

public class Circle2 {
	private Punkt mittelpunkt;
	private double radius;
	
	public Circle2 (Punkt punkt, double ir) 
   	{ mittelpunkt = punkt; radius = ir; }
   	
   	public int getX () { return mittelpunkt.getX(); } 
   	public int getY () { return mittelpunkt.getY(); }
   	public double getRadius () { return radius; }

  	public void grow (double dr) { radius += dr; }
   	public void move (int dx, int dy) { mittelpunkt.move(dx,dy); }
   	public void drucke () {
   		System.out.print("Ich bin ein Kreis mit Mittelpunkt ");
   		System.out.println("(" + mittelpunkt.getX() + " , " + 
   		                         mittelpunkt.getY() + ")");
   		System.out.println(" und Radius " + radius);
   	}
}
