public class ArrayAufsummieren {

	public static void main(String[] args) {
		int [] zahlen = new int[6];
		zahlen[0]=77;
		zahlen[1]=13;
		zahlen[2]=77;
		zahlen[3]=31;
		zahlen[4]=40;
		zahlen[5]=55;
		
		int sum=0;
		
		for(int i=0; i< zahlen.length;i++){
			sum+=zahlen[i];
		}
		System.out.println("Die Summe der Zahlen lautet: "+ sum);

	}

}
