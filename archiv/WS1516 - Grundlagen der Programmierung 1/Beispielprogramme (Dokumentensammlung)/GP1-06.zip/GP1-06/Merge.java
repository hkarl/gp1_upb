
public class Merge {

	public static void main(String[] args) {
		int[] a = {-5, -4, 1, 3, 100, 321};
		int[] b = {0, 1, 25, 99};
		int[] c = new int[a.length + b.length];
		int lefta = 0;
		int leftb = 0;
		int leftc = 0;
		while (lefta < a.length & leftb < b.length) {
		// beide Arrays noch nicht fertig
			if (a[lefta]<b[leftb]) { c[leftc]=a[lefta]; lefta++; }
			else { c[leftc]=b[leftb]; leftb++; }
			leftc++;
		};
		// Reste einer der beiden Arrays hinten dran kopieren
		while (lefta < a.length) {
			c[leftc] = a[lefta];
			leftc++;
			lefta++;
			};
		while (leftb < b.length) {
			c[leftc] = b[leftb];
			leftc++;
			leftb++;
			};
		for (int i = 0; i < c.length; i++) {
			System.out.print(c[i]+" ");
			} } 

}


