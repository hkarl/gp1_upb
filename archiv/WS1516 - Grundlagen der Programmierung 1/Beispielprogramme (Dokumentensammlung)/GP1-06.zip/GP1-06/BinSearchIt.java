
public class BinSearchIt {

	public static void main(String[] args) {
		int [] array = { -4, 2, 24, 313, 500, 501, 666, 777, 1000};
		int val = 777;
		int low = 0; 
		int up = array.length-1;
		int mid; 
		int midval;
		boolean found = false;
		while (! found & !(up < low)) {
			mid = (low + up)/2; midval = array[mid];
			if (val == midval) found = true;
			if (val < midval) up = mid -1;
			if (val > midval) low = mid +1; };
			System.out.println(found);

	}

}
