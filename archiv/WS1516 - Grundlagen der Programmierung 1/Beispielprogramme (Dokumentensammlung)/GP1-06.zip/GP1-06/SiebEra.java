public class SiebEra {
	public static void main (String [] args) {
		// Einlesen von n
		int n = Integer.parseInt(args[0]);
		// Tabelle erstellen
		boolean [] tabelle = new boolean[n+1];
		for (int i = 2; i <= n; i++)
		tabelle[i] = true; // noch nichts gestrichen
		// Tabelle bearbeiten
		for (int naechste = 2; naechste <= n; naechste++) {
			if (tabelle[naechste]) { // noch nicht gestrichen?
				System.out.println(naechste);
				// Streichen der Vielfachen
				for (int i = 2 * naechste; i <= n; i+= naechste)
					tabelle[i] = false;
			}
		}
	}
}
